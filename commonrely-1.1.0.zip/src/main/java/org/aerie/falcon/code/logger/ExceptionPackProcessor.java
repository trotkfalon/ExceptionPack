package org.aerie.falcon.code.logger;

import java.util.Optional;

import org.aerie.falcon.code.exception.CustomException;
import org.aerie.falcon.code.exception.ExceptionGradeEnum;
import org.aerie.falcon.code.exception.ExceptionPack;
import org.aerie.falcon.code.ui.PopUpWindows;
import org.aerie.falcon.code.util.ExceptionCustomUtil;

/**
 * 
 * @description 全局日志配置器私有的异常包装处理器
 * @author falconTrotk
 * @company aerie
 * @date 2019年2月10日下午12:55:07
 * @version 1.0.1
 */
public enum ExceptionPackProcessor {
	INSTANCE;

	private ExceptionPackProcessor() {
		// Do Nothing
	}

	/**
	 * 
	 * @description 处理异常信息包
	 * @author falconTrotk
	 * @throws CustomException
	 * @company aerie
	 * @date 2019年2月10日下午12:35:33
	 */
	public void recordExceptionPack(String message, ExceptionPack exceptionPack) {
		// 自处理空异常包direct
		if (null == exceptionPack) {
			GlobalLogger.INSTANCE.loggerException("禁止处理空异常包", ExceptionGradeEnum.ERROR);
			GlobalLogger.INSTANCE.loggerExcStackTrace("lead to------>无法判断此处异常的等级,请尽快处理", ExceptionGradeEnum.ERROR);
			try {
				GlobalLogger.INSTANCE.loggerExcStackTrace(
						ExceptionCustomUtil.getStackTraceFormatting(new CustomException("无意义的"), 1),
						ExceptionGradeEnum.ERROR);
			} catch (ExceptionPack e) {
				GlobalLogger.INSTANCE.loggerException("处理异常失败", e, ExceptionGradeEnum.ERROR);
			}
			return;
		}
		// 处理异常包
		try {
			GlobalLogger.INSTANCE.loggerExcStackTrace(
					"------------------------------------------------------------>[direct   cause]",
					exceptionPack.getExceptionGradeEnum());
			// 打印直接异常信息
			GlobalLogger.INSTANCE.loggerException(message, exceptionPack.getExceptionGradeEnum());
			// 打印直接异常的产生的位置
			GlobalLogger.INSTANCE.loggerExcStackTrace(
					ExceptionCustomUtil.getStackTraceBeginLine(new CustomException("无意义的"), 2),
					exceptionPack.getExceptionGradeEnum());
			// 弹窗处理【现在只对直接异常做弹窗处理】
			disposeCustomException(exceptionPack);
			// 处理间接异常
			recordIndirectException(exceptionPack);
		} catch (ExceptionPack e) {
			GlobalLogger.INSTANCE.loggerException("处理异常失败", e, e.getExceptionGradeEnum());
		} catch (CustomException e) {
			GlobalLogger.INSTANCE.loggerExcStackTrace(e.getMessage(), ExceptionGradeEnum.ERROR);
		}
		// 打印根本异常信息
		try {
			GlobalLogger.INSTANCE.loggerExcStackTrace(
					"be caused by:\n\t---------------------------------------------------->[primary  cause]",
					getPrimaryException(exceptionPack), exceptionPack.getExceptionGradeEnum());
		} catch (CustomException e) {
			GlobalLogger.INSTANCE.loggerExcStackTrace(e.getMessage(), exceptionPack.getExceptionGradeEnum());
		}
	}

	/**
	 * 递归获得根本异常
	 * 
	 * @param exceptionPack
	 * @return
	 * @throws CustomException
	 */
	private Throwable getPrimaryException(ExceptionPack exceptionPack) throws CustomException {
		Optional.ofNullable(exceptionPack).orElseThrow(() -> new CustomException("异常包装内部信息丢失-->无法处理"));
		Throwable throwable = Optional.ofNullable(exceptionPack.getThrowable())
				.orElseThrow(() -> new CustomException("异常包装内部信息丢失-->无法处理"));
		if (throwable instanceof ExceptionPack) {
			// 递归处理
			return getPrimaryException((ExceptionPack) throwable);
		}
		return throwable;
	}

	/**
	 * 处理间接异常
	 * 
	 * @param exceptionPack
	 * @param index
	 * @return
	 * @throws CustomException
	 * @throws ExceptionPack
	 */
	private void recordIndirectException(ExceptionPack exceptionPack) throws CustomException, ExceptionPack {
		Optional.ofNullable(exceptionPack).orElseThrow(() -> new CustomException("异常包装内部信息丢失-->无法处理"));
		GlobalLogger.INSTANCE.loggerExcStackTrace(
				"be caused by:\n\t---------------------------------------------------->[indirect cause]",
				exceptionPack.getExceptionGradeEnum());
		// 打印间接异常信息
		GlobalLogger.INSTANCE.loggerException(exceptionPack.getMessage(), exceptionPack.getExceptionGradeEnum());
		// 打印间接异常的产生的位置
		GlobalLogger.INSTANCE.loggerExcStackTrace(ExceptionCustomUtil.getStackTraceFormatting(exceptionPack, 0),
				exceptionPack.getExceptionGradeEnum());
		if (exceptionPack.getThrowable() instanceof ExceptionPack) {
			recordIndirectException((ExceptionPack) exceptionPack.getThrowable());
		}
	}

	/**
	 * 
	 * @description 异常包装的弹窗提示处理
	 * @param exceptionPack
	 * @author falconTrotk
	 * @company aerie
	 * @date 2019年2月10日下午10:03:32
	 */
	private void disposeCustomException(ExceptionPack exceptionPack) {
		if (exceptionPack == null) {
			return;
		}
		ExceptionGradeEnum exceptionGradeEnum = exceptionPack.getExceptionGradeEnum();
		if (exceptionGradeEnum == null || exceptionPack.isWhetherPopUp() == false) {
			return;
		}
		switch (exceptionGradeEnum) {
		case INFO:
			PopUpWindows.info(exceptionPack.getMessage());
			break;
		case WARN:
			PopUpWindows.warn(exceptionPack.getMessage());
			break;
		case ERROR:
			PopUpWindows.error();
			break;
		}
	}
}
