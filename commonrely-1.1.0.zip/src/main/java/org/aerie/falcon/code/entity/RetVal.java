package org.aerie.falcon.code.entity;

import lombok.Builder;
import lombok.Data;

/**
 * 
 * @description 请求返回信息的包装类
 * @author zhangqi
 * @company szxy
 * @version 1.1.0
 * @date 2019年3月14日上午9:19:46
 */
@Data
@Builder
public class RetVal {
	/**
	 * 错误代码
	 */
	private int errCode;
	/**
	 * 错误信息
	 */
	private String errmsg;
	/**
	 * 返回的对象
	 */
	private Object data;
}
