/**
 * 
 * @description 异常包
 * @author falconTrotk
 * @company aerie
 * @date 2019年2月10日下午12:55:07
 * @version 1.0.1
 */
package org.aerie.falcon.code.logger;
