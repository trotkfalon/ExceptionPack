package org.aerie.falcon.code.util;

import java.util.Optional;
import java.util.regex.Pattern;

import org.aerie.falcon.code.exception.CustomException;

/**
 * 
 * @description 正则工具类
 * @author trotkfalcon
 * @company aerie
 * @date 2019年3月15日上午12:41:20
 * @version 1.1.0
 */
public class RegularUtil {
	/**
	 * 整数的正则(可以匹配正负号)
	 */
	public static final String INTEGER = "^[-+]?\\d*[1-9]|0$";
	/**
	 * 正整数的正则(可以匹配正号)【不包括0】
	 */
	public static final String POSINT_INTEGER = "^[+]?[1-9]\\d*$";
	/**
	 * 负整数的正则【不包括0】
	 */
	public static final String NEGATIV_INTEGER = "^[-]+[1-9]\\d*$";
	/**
	 * 战机的加成的正则【大于1的最多两位小数】
	 */
	public static final String ADDITION = "^[1-9]\\d*(\\.\\d{0,2})?$";
	/**
	 * 实数的正则(可以匹配正号)【0没有正负号和小数位，小数的最后一位不能为0】
	 */
	public static final String REAL_NUMBER = "^[-+]?[1-9]+\\d*(\\.\\d*[1-9])*|[-+]?0(\\.\\d*[1-9])|[-+]?0$";
	/**
	 * 钱数【大于等于0，最多两位小数】
	 */
	public static final String MONEY_NUMBER = "^[1-9]\\d*\\.\\d{1,2}|0\\.[1-9]\\d{0,1}|0\\.0[1-9]$|[1-9]\\d*|0";
	/**
	 * 手机号正则（2018年新增166）
	 */
	public static final String PHONENUMBER = "^(((13[0-9])|(14[579])|(15([0-3]|[5-9]))|(16[6])|(17[0135678])|(18[0-9])|(19[89]))\\d{8})$";
	/**
	 * 邮箱的正则
	 */
	public static final String EMAIL = "^([a-z0-9A-Z]+[-|_|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,6}$";
	/**
	 * 用户名的正则【字母开头，6到18位】
	 */
	public static final String USER_NAME = "^[a-zA-Z]\\w{5,17}$";

	private RegularUtil() {
		super();
	}

	/**
	 * 判断被校验的字符串是否符合对应的正则表达式
	 * 
	 * @param regular
	 * @param checked
	 * @return
	 * @throws CustomException
	 */
	public static boolean isConform(String regular, String checked) throws CustomException {
		Optional.ofNullable(regular).filter(p1 -> !p1.isEmpty())
				.orElseThrow(() -> new CustomException("正则表达式不能为空或者空字符串"));
		return Pattern.compile(regular).matcher(Optional.ofNullable(checked).orElse("")).matches();
	}
}
