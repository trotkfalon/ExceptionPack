package org.aerie.falcon.code.function.injecter;

/**
 * 
 * @description 功能的动作
 * @author trotkfalcon
 * @company aerie
 * @date 2019年3月15日上午12:34:41
 * @version 1.1.0
 */
public interface Injecter {
	/**
	 * 嵌入的动作
	 */
	public void action();
}