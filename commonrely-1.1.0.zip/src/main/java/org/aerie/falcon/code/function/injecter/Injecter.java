package org.aerie.falcon.code.function.injecter;

/**
 * 
 * @description 功能的动作
 * @author zhangqi
 * @company szxy
 * @version 1.1.0
 * @date 2019年3月14日上午9:29:05
 */
public interface Injecter {
	/**
	 * 嵌入的动作
	 */
	public void action();
}