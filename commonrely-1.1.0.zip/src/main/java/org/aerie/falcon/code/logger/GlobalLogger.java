package org.aerie.falcon.code.logger;

import java.util.Optional;

import org.aerie.falcon.code.exception.ExceptionGradeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @description 全局日志配置器
 * @author falconTrotk
 * @company aerie
 * @date 2019年2月10日下午12:38:03
 * @version 1.0.1
 */
@Slf4j(topic = "Logger")
public enum GlobalLogger {
	INSTANCE;
	/**
	 * 全局异常信息日志
	 */
	private final static Logger EXCEPTION_LOGGER = LoggerFactory.getLogger("ExceptionLogger");
	/**
	 * 全局异常堆栈信息日志
	 */
	private final static Logger EXC_STACK_TRACE_LOGGER = LoggerFactory.getLogger("ExcStackTraceLogger");

	public Logger getLogger() {
		return log;
	}

	void loggerException(String message) {
		loggerException(message, null, null);
	}

	void loggerException(String message, Throwable throwable) {
		loggerException(message, throwable, null);
	}

	void loggerException(String message, ExceptionGradeEnum enumExceptionGradeEnum) {
		loggerException(message, null, enumExceptionGradeEnum);
	}

	void loggerException(String message, Throwable throwable, ExceptionGradeEnum enumExceptionGradeEnum) {
		switch (Optional.ofNullable(enumExceptionGradeEnum).orElse(ExceptionGradeEnum.ERROR)) {
		case INFO:
			EXCEPTION_LOGGER.info(message, throwable);
			break;
		case WARN:
			EXCEPTION_LOGGER.warn(message, throwable);
			break;
		case ERROR:
			EXCEPTION_LOGGER.error(message, throwable);
			break;
		}
	}

	void loggerExcStackTrace(String message) {
		loggerExcStackTrace(message, null, null);
	}

	void loggerExcStackTrace(String message, Throwable throwable) {
		loggerExcStackTrace(message, throwable, null);
	}

	void loggerExcStackTrace(String message, ExceptionGradeEnum enumExceptionGradeEnum) {
		loggerExcStackTrace(message, null, enumExceptionGradeEnum);
	}

	void loggerExcStackTrace(String message, Throwable throwable, ExceptionGradeEnum enumExceptionGradeEnum) {
		switch (Optional.ofNullable(enumExceptionGradeEnum).orElse(ExceptionGradeEnum.ERROR)) {
		case INFO:
			EXC_STACK_TRACE_LOGGER.info(message, throwable);
			break;
		case WARN:
			EXC_STACK_TRACE_LOGGER.warn(message, throwable);
			break;
		case ERROR:
			EXC_STACK_TRACE_LOGGER.error(message, throwable);
			break;
		}
	}
}
