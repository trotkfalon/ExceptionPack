package org.aerie.falcon.code;

import java.io.File;
import java.io.FileInputStream;

import org.aerie.falcon.code.exception.ExceptionGradeEnum;
import org.aerie.falcon.code.exception.ExceptionPack;
import org.aerie.falcon.code.logger.ExceptionPackProcessor;

public class Test {
	public static void main(String[] args) {
		getssssss();
	}

	public static void getssssss() {
		try {
			getSSS();
		} catch (ExceptionPack exceptionPack) {
			ExceptionPackProcessor.INSTANCE.recordExceptionPack("直接原因", exceptionPack);
		}
	}

	public static void getSSS() throws ExceptionPack {

		try {
			getSSSs();
		} catch (ExceptionPack e) {
			throw new ExceptionPack("间接原因2", e, ExceptionGradeEnum.WARN, false);
		}

	}

	public static void getSSSs() throws ExceptionPack {
		try {
			File file = new File("");
			@SuppressWarnings("resource")
			FileInputStream fileInputStream = new FileInputStream(file);
			fileInputStream.available();
		} catch (Exception e) {
			throw new ExceptionPack("间接原因1", e, ExceptionGradeEnum.WARN, false);
		}
	}
}
