package org.aerie.falcon.code.ui;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import org.aerie.falcon.code.function.injecter.popupwindow.PopUpWindowFunction;

/**
 * 
 * @description 弹窗的包装类
 * @author falconTrotk
 * @company aerie
 * @date 2019年2月10日下午10:40:54
 * @version 1.0.1
 */
public class PopUpWindows extends JOptionPane {

	private static final long serialVersionUID = 1L;

	/**
	 * 
	 * @description 提示信息弹窗
	 * @param message
	 * @author falconTrotk
	 * @company aerie
	 * @date 2019年2月10日下午10:40:29
	 */
	public static void info(String message) {
		showMessageDialog(null, message, "尊敬的用户:", JOptionPane.INFORMATION_MESSAGE);
	}

	/**
	 * 
	 * @description 警告信息弹窗【不会对程序造成不可逆转的影响，但是会影响体验的信息】
	 * @param message
	 * @author falconTrotk
	 * @company aerie
	 * @date 2019年2月10日下午10:40:07
	 */
	public static void warn(String message) {
		showMessageDialog(null, message, "请注意:", JOptionPane.WARNING_MESSAGE);
	}

	/**
	 * 
	 * @description 致命错误
	 * @author falconTrotk
	 * @company aerie
	 * @date 2019年2月10日下午10:38:45
	 */
	public static void error() {
		showMessageDialog(null, "游戏运行出错,请联系客服!", "感谢您的支持", JOptionPane.ERROR_MESSAGE);
		// 严重错误退出程序
		System.exit(0);
	}

	/**
	 * 
	 * @description 选择弹窗
	 * @param jLabel
	 * @param popUpWindowFunction
	 * @author falconTrotk
	 * @company aerie
	 * @date 2019年2月10日下午10:39:03
	 */
	public static void choice(JLabel jLabel, PopUpWindowFunction popUpWindowFunction) {
		if (showConfirmDialog(null, jLabel, "", JOptionPane.YES_NO_OPTION) == 0)
			popUpWindowFunction.action();
	}

	/**
	 * 
	 * @description 选择弹窗
	 * @param message
	 * @param popUpWindowFunction
	 * @author falconTrotk
	 * @company aerie
	 * @date 2019年2月10日下午10:39:50
	 */
	public static void choice(String message, PopUpWindowFunction popUpWindowFunction) {
		if (showConfirmDialog(null, message, "", JOptionPane.YES_NO_OPTION) == 0)
			popUpWindowFunction.action();
	}
}
