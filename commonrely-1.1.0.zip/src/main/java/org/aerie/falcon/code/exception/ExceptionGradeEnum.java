package org.aerie.falcon.code.exception;

import org.aerie.falcon.code.logger.GlobalLogger;

/**
 * 
 * @description 异常的等级【枚举】
 * @author zhangqi
 * @company szxy
 * @version 1.1.0
 * @date 2019年3月14日上午9:26:03
 */
public enum ExceptionGradeEnum {
	/**
	 * 信息
	 */
	INFO("信息"),
	/**
	 * 警告
	 */
	WARN("警告"),
	/**
	 * 错误
	 */
	ERROR("错误");
	/**
	 * 等级解释
	 */
	private final String MSG;

	private ExceptionGradeEnum(String msg) {
		this.MSG = msg;
		GlobalLogger.INSTANCE.getLogger().trace("【单例】异常等级【" + this.name() + ":" + this.MSG + "】初始化");
	}

	public String getMSG() {
		return MSG;
	}

}
