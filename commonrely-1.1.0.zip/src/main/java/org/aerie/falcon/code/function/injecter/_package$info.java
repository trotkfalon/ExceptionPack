/**
 * 
 * @description 入注功能包
 * @author trotkfalcon
 * @company aerie
 * @date 2019年3月15日上午12:34:41
 * @version 1.1.0
 */
package org.aerie.falcon.code.function.injecter;