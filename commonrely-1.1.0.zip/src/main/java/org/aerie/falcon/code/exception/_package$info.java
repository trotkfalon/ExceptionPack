/**
 * 
 * @description 异常包
 * @author zhangqi
 * @company szxy
 * @version 1.1.0
 * @date 2019年3月14日上午9:18:51
 */
package org.aerie.falcon.code.exception;
