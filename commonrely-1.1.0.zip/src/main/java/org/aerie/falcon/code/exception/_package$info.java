/**
 * 
 * @description 异常包
 * @author trotkfalcon
 * @company aerie
 * @date 2019年3月14日下午10:27:33
 * @version 1.1.0
 */
package org.aerie.falcon.code.exception;
