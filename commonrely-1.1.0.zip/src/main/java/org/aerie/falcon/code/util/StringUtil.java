package org.aerie.falcon.code.util;

/**
 * 
 * @Description : 字符串工具类
 * @Author : falcon
 * @Company : aerie
 * @Date : 2019年1月9日下午1:43:16
 */
public class StringUtil {
	// TODO
	public static int getStrNum(String str, String key) {
		int count = 0, start = 0;
		while ((start = str.indexOf(key, start)) >= 0) {
			start += key.length();
			count++;
		}
		return count;
	}
}