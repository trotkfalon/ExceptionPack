package org.aerie.falcon.code.exception;

import java.util.Optional;

/**
 * 
 * @description 异常包装【将异常包装起来，用包装异常处理器处理】
 * @author trotkfalcon
 * @company aerie
 * @date 2019年3月15日上午12:31:25
 * @version 1.1.0
 */
public class ExceptionPack extends Throwable {
	private static final long serialVersionUID = 1L;
	/**
	 * 需要被包装处理的throwable
	 */
	private Throwable throwable;
	/**
	 * 自定义异常的等级
	 */
	private ExceptionGradeEnum exceptionGradeEnum;
	/**
	 * 是否弹窗
	 */
	private boolean whetherPopUp = false;

	/**
	 * 
	 * @param message
	 * @param throwable
	 * @param exceptionGradeEnum
	 */
	public ExceptionPack(String message, Throwable throwable, ExceptionGradeEnum exceptionGradeEnum) {
		super(message);
		this.throwable = throwable;
		this.exceptionGradeEnum = Optional.ofNullable(exceptionGradeEnum).orElse(ExceptionGradeEnum.WARN);
	}

	/**
	 * 
	 * @param message
	 * @param throwable
	 * @param exceptionGradeEnum
	 * @param whetherPopUp
	 */
	public ExceptionPack(String message, Throwable throwable, ExceptionGradeEnum exceptionGradeEnum,
			boolean whetherPopUp) {
		super(message);
		this.throwable = throwable;
		this.exceptionGradeEnum = Optional.ofNullable(exceptionGradeEnum).orElse(ExceptionGradeEnum.WARN);
		this.whetherPopUp = Optional.ofNullable(whetherPopUp).orElse(false);
	}

	public Throwable getThrowable() {
		return throwable;
	}

	public ExceptionGradeEnum getExceptionGradeEnum() {
		return exceptionGradeEnum;
	}

	public boolean isWhetherPopUp() {
		return whetherPopUp;
	}
}
