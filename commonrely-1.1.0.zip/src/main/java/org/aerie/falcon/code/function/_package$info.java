/**
 * 
 * @description 功能包接口
 * @author trotkfalcon
 * @company aerie
 * @date 2019年3月15日上午12:35:50
 * @version 1.1.0
 */
package org.aerie.falcon.code.function;
