package org.aerie.falcon.code.function.injecter.exceptiondispose;

import org.aerie.falcon.code.function.injecter.Injecter;

/**
 * 
 * @description 异常处理动作
 * @author zhangqi
 * @company szxy
 * @version 1.1.0
 * @date 2019年3月14日上午9:30:02
 */
@FunctionalInterface
public interface ExceptionDisposeFunction extends Injecter {

}
