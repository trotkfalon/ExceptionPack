package org.aerie.falcon.code.exception;

/**
 * 
 * @description 自定义异常
 * @author zhangqi
 * @company szxy
 * @version 1.1.0
 * @date 2019年3月14日上午9:20:46
 */
public class CustomException extends Exception {
	private static final long serialVersionUID = 1L;

	public CustomException(String message) {
		super(message);
	}
}
