package org.aerie.falcon.code.exception;

/**
 * 
 * @description 自定义异常
 * @author trotkfalcon
 * @company aerie
 * @date 2019年3月15日上午12:16:11
 * @version 1.1.0
 */
public class CustomException extends Exception {
	private static final long serialVersionUID = 1L;

	public CustomException(String message) {
		super(message);
	}
}
