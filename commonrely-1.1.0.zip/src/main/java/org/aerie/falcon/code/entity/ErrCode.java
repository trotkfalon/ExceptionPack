package org.aerie.falcon.code.entity;

/**
 * 
 * @description 请求错误信息代码【枚举】
 * @author zhangqi
 * @company szxy
 * @version 1.1.0
 * @date 2019年3月14日上午9:18:51
 */
public enum ErrCode {
	/**
	 * 请求成功
	 */
	SUCCESS(200),
	/**
	 * 登陆失败
	 */
	LOGIN_ERROR(202),
	/**
	 * 登陆过期
	 */
	LOGIN_EXPIRE(203),
	/**
	 * 权限受限
	 */
	ACCESS_LIMITED(301),
	/**
	 * 参数错误
	 */
	ARGS_ERROR(501),
	/**
	 * 未知错误
	 */
	UNKOWN_ERROR(502),
	/**
	 * 插入数据库错误
	 */
	INSERT_ERROR(503),
	/**
	 * 更新数据库失败
	 */
	UPDATE_ERROR(504),
	/**
	 * 上传文件失败
	 */
	UPLOAD_ERROR(506),
	/**
	 * 删除失败
	 */
	DELETE_ERROR(507);
	/**
	 * 错误代码编号
	 */
	private final int CODE;

	private ErrCode(int CODE) {
		this.CODE = CODE;
	}

	public int getCODE() {
		return CODE;
	}
}
