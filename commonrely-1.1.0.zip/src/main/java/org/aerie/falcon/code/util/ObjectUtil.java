package org.aerie.falcon.code.util;

/**
 * @description
 * @author falconTrotk
 * @company aerie
 * @date 2019年2月20日下午10:35:10
 * @version 1.0.1
 */
public class ObjectUtil {

}
