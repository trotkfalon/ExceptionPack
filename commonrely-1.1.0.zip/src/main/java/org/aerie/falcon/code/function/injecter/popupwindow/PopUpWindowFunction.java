package org.aerie.falcon.code.function.injecter.popupwindow;

import org.aerie.falcon.code.function.injecter.Injecter;

/**
 * 
 * @description 弹窗动作
 * @author zhangqi
 * @company szxy
 * @version 1.1.0
 * @date 2019年3月14日上午9:29:46
 */
@FunctionalInterface
public interface PopUpWindowFunction extends Injecter {

}