package org.aerie.falcon.code.function.injecter.popupwindow;

import org.aerie.falcon.code.function.injecter.Injecter;

/**
 * 
 * @description 弹窗动作
 * @author trotkfalcon
 * @company aerie
 * @date 2019年3月15日上午12:35:30
 * @version 1.1.0
 */
@FunctionalInterface
public interface PopUpWindowFunction extends Injecter {

}